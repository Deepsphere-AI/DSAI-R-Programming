
/*******************************************************************************************

File Name       :   CSLAB_DATA_INTEGRATION_CROSS_JOIN
Purpose 	:   A Program for Data Integration - Cross Join in R
Author		:   Durga Prasad
Reviewer 	:   Jothi Periasamy
Date and Time	:   16/01/2019 20:18 hrs
Version		:   1.0	
Change History 	: 

____________________________________________________________________________________________

	Who				 When 			       Why
____________________________________________________________________________________________


	DP			      16/01/2019		  Initital Release 

____________________________________________________________________________________________


/*******************************************************************************************

## Program Description : A Program for Data Integration - Cross Join in R

## R Development Environment & Runtime - R Studio, Anaconda, Jupyter Notebook

vAR_CSLAB_df1 = data.frame(CustomerId = c(1:6), Product = c(rep("Toaster", 3), rep("Radio", 3)))

vAR_CSLAB_df2 = data.frame(CustomerId = c(2, 4, 6), State = c(rep("Alabama", 2), rep("Ohio", 1)))

vAR_CSLAB_df1_df2_Cross_Join = merge(x = vAR_CSLAB_df1, y = vAR_CSLAB_df2, by = NULL)

vAR_CSLAB_df1_df2_Cross_Join

/*******************************************************************************************
Disclaimer.

      We are providing this code block strictly for learning and researching, this is not a 
production ready code. We have no liability on this particular code under any circumstances; 
users should use this code on their own risk. All software, hardware and othr products that 
are referenced in these materials belong to the respective vendor who developed or who owns 
this product.

/*******************************************************************************************



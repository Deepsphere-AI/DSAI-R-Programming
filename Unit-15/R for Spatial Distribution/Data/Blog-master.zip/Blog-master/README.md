## Aim

This is a repository where I will put (from now on) all the codes that I use in my [blog post](https://biologyforfun.wordpress.com).

## Structure

Individual posts will get a different folder so head over there to see the code.
